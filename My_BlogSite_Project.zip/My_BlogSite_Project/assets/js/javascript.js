
    // Get the modal of subscreibe form
    var modal = document.getElementById('subscribeform');
    
    